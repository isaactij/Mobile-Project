//
//  PersistentService.swift
//  Binder
//
//  Created by Brandon Kerbow on 3/25/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import Foundation
import CoreData

class PersistenceService {
    
    // Provide external access to this Singleton.
    static let shared = PersistenceService()
    
    private var people: [NSManagedObject]!
    private var assignments: [NSManagedObject]!
    private var courses: [NSManagedObject]!
    private var peopleInCourses: [NSManagedObject]!
    
    // MARK: - Core Data stack
    
    private var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    private lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "Binder")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // We want this class to be a Singleton.
    // To keep it that way, don't allow any code outside this class to instantiate an object of this type.
    private init() {}
    
    func countPeople() -> Int {
        return people.count
    }
    
    func countAssignments() -> Int {
        return assignments.count
    }
    
    func countCourses() -> Int {
        return courses.count
    }
    
    func countPeopleInCourses() -> Int {
        return peopleInCourses.count
    }
    
    func getPeople(index:Int) -> People {
        if index < people.count {
            let p = people[index]
            let n = p.value(forKey: "personID") as! Int
            let a = p.value(forKey: "username") as! String
            let b = p.value(forKey: "password") as! String
            return People(username: a, password: b, personID: n)
        } else {
            return People(username: "<bad>", password: "<bad>", personID: 0)
        }
    }
    
    func getCourse(index:Int) -> Courses {
        if index < courses.count {
            let p = courses[index]
            let n = p.value(forKey: "courseID") as! Int
            let a = p.value(forKey: "courseName") as! String
            let b = p.value(forKey: "courseAbbreviation") as! String
            return Courses(courseName: a, courseAbbreviation: b, courseID: n)
        } else {
            return Courses(courseName: "<bad>", courseAbbreviation: "<bad>", courseID: 0)
        }
    }
    func getAssignment(index:Int) -> Assignments {
        if index < assignments.count {
            let p = assignments[index]
            let n = p.value(forKey: "assignmentID") as! Int
            let a = p.value(forKey: "assignmentType") as! String
            let b = p.value(forKey: "courseID") as! Int
            let c = p.value(forKey: "percentOfGrade") as! Int
            return Assignments(assignmentID: n, assignmentType: a, courseID: b, percentOfGrade: c)
        } else {
            return Assignments(assignmentID: 0, assignmentType: "<bad>", courseID: 0, percentOfGrade: 0)
        }
    }
    func getPeopleinCourses(index:Int) -> PeopleInCourses {
        if index < peopleInCourses.count {
            let p = peopleInCourses[index]
            let n = p.value(forKey: "pk") as! Int
            let a = p.value(forKey: "personID") as! Int
            let b = p.value(forKey: "courseID") as! Int
            return PeopleInCourses(courseID: b, personID: a, pk: n)
        } else {
            return PeopleInCourses(courseID: 0, personID: 0, pk: 0)
        }
    }
    
    
    
    
    func fetchPeople() {
        
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"People")
        
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.fetch(fetchRequest) as? [NSManagedObject]
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        guard let results = fetchedResults else { return }
        
        people = results
    }
    
    func fetchCourses() {
        
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Courses")
        
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.fetch(fetchRequest) as? [NSManagedObject]
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        guard let results = fetchedResults else { return }
        
        courses = results
    }
    
    func fetchAssignments() {
        
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Assignments")
        
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.fetch(fetchRequest) as? [NSManagedObject]
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        guard let results = fetchedResults else { return }
        
        assignments = results
    }
    
    func fetchPeopleInCourses() {
        
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"PeopleInCourses")
        
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.fetch(fetchRequest) as? [NSManagedObject]
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        guard let results = fetchedResults else { return }
        
        peopleInCourses = results
    }
    
    
    
    
    func savePerson(personID: Int, username: String, password: String) {
        
        let managedContext = persistentContainer.viewContext
        
        // Create the entity we want to save
        let entity = NSEntityDescription.entity(forEntityName: "People", in: managedContext)
        
        let person = NSManagedObject(entity: entity!, insertInto:managedContext)
        
        // Set the attribute values
        person.setValue(Int(personID), forKey: "personID")
        person.setValue(username, forKey: "username")
        person.setValue(password, forKey: "password")
        
        // Commit the changes.
        do {
            try managedContext.save()
            people.append(person)
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    func saveAssignments(assignmentID: Int, assignmentType: String, courseID: Int, percentOfGrade: Int) {
        
        let managedContext = persistentContainer.viewContext
        
        // Create the entity we want to save
        let entity = NSEntityDescription.entity(forEntityName: "Assingments", in: managedContext)
        
        let assignmentsA = NSManagedObject(entity: entity!, insertInto:managedContext)
        
        // Set the attribute values
        assignmentsA.setValue(Int(assignmentID), forKey: "assignmentID")
        assignmentsA.setValue(assignmentType, forKey: "assignmentType")
        assignmentsA.setValue(Int(courseID), forKey: "courseID")
        assignmentsA.setValue(Int(percentOfGrade), forKey: "percentOfGrade")
        
        // Commit the changes.
        do {
            try managedContext.save()
            assignments.append(assignmentsA)
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    func saveCourses(courseAbbreviation: String, courseID: Int, courseName: String) {
        
        let managedContext = persistentContainer.viewContext
        
        // Create the entity we want to save
        let entity = NSEntityDescription.entity(forEntityName: "Courses", in: managedContext)
        
        let coursesA = NSManagedObject(entity: entity!, insertInto:managedContext)
        
        // Set the attribute values
        coursesA.setValue(courseAbbreviation, forKey: "courseAbbreviation")
        coursesA.setValue(Int(courseID), forKey: "courseID")
        coursesA.setValue(courseName, forKey: "courseName")
        
        // Commit the changes.
        do {
            try managedContext.save()
            courses.append(coursesA)
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    func savePeopleInCourses(courseID: Int, personID: Int, pk: Int) {
        
        let managedContext = persistentContainer.viewContext
        
        // Create the entity we want to save
        let entity = NSEntityDescription.entity(forEntityName: "PeopleInCourses", in: managedContext)
        
        let peopleInCoursesA = NSManagedObject(entity: entity!, insertInto:managedContext)
        
        // Set the attribute values
        peopleInCoursesA.setValue(Int(courseID), forKey: "courseID")
        peopleInCoursesA.setValue(Int(personID), forKey: "personID")
        peopleInCoursesA.setValue(Int(pk), forKey: "pk")
        
        // Commit the changes.
        do {
            try managedContext.save()
            peopleInCourses.append(peopleInCoursesA)
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
}
