//
//  CreateTaskViewController.swift
//  Binder
//
//  Created by Isaac on 4/15/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import UIKit
import EventKit

class CreateTaskViewController: UIViewController {
    @IBOutlet weak var taskDescriptionTextInput: UITextField!
    @IBOutlet weak var deadlineDateTextField: UITextField!
    @IBOutlet weak var deadlineTimeTextField: UITextField!
    @IBOutlet weak var reminderDateTextField: UITextField!
    @IBOutlet weak var reminderTimeTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    var deadline:String = ""
    var reminder:String = ""
    
    let pickerDeadlineDate = UIDatePicker()
    let pickerReminderDate = UIDatePicker()
    let pickerDeadlineTime = UIDatePicker()
    let pickerReminderTime = UIDatePicker()
    let eventStore = EKEventStore()
    var calendars: [EKCalendar]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        deadlineDateTextField.text = ""
        deadlineTimeTextField.text = ""
        reminderDateTextField.text = ""
        reminderTimeTextField.text = ""
        errorLabel.text = ""
        createDatePicker()
    }
    
    func createDatePicker(){
        let toolbarDD = UIToolbar()
        toolbarDD.sizeToFit()
        let doneDD = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedDD))
        toolbarDD.setItems([doneDD], animated: false)
        
        deadlineDateTextField.inputAccessoryView = toolbarDD
        deadlineDateTextField.inputView = pickerDeadlineDate
        
        let toolbarRR = UIToolbar()
        toolbarRR.sizeToFit()
        let doneRR = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedRR))
        toolbarRR.setItems([doneRR], animated: false)
        reminderDateTextField.inputAccessoryView = toolbarRR
        reminderDateTextField.inputView = pickerReminderDate
        
        let toolbarDT = UIToolbar()
        toolbarDT.sizeToFit()
        let doneDT = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedDT))
        toolbarDT.setItems([doneDT], animated: false)
        deadlineTimeTextField.inputAccessoryView = toolbarDT
        deadlineTimeTextField.inputView = pickerDeadlineTime
        
        let toolbarRT = UIToolbar()
        toolbarRT.sizeToFit()
        let doneRT = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedRT))
        toolbarRT.setItems([doneRT], animated: false)
        reminderTimeTextField.inputAccessoryView = toolbarRT
        reminderTimeTextField.inputView = pickerReminderTime
        
        pickerDeadlineDate.datePickerMode = .date
        pickerReminderDate.datePickerMode = .date
        pickerDeadlineTime.datePickerMode = .time
        pickerReminderTime.datePickerMode = .time
    }
    
    @objc func donePressedDT() {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        let deadlineTimeString = formatter.string(from: pickerDeadlineTime.date)
        deadlineTimeTextField.text = "\(pickerDeadlineTime.date)"
        self.view.endEditing(true)
    }
    
    @objc func donePressedRT() {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        let reminderTimeString = formatter.string(from: pickerReminderTime.date)
        reminderTimeTextField.text = "\(reminderTimeString)"
        self.view.endEditing(true)
    }
    
    @objc func donePressedDD() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        let deadlineDateString = formatter.string(from: pickerDeadlineDate.date)
        deadlineDateTextField.text = "\(deadlineDateString)"
        self.view.endEditing(true)
    }
    
    @objc func donePressedRR() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        let reminderDateString = formatter.string(from: pickerReminderDate.date)
        reminderDateTextField.text = "\(reminderDateString)"
        self.view.endEditing(true)
    }

    @IBAction func saveButtonPressed(_ sender: Any) {
        var description = taskDescriptionTextInput.text
        description = description?.trimmingCharacters(in: .whitespacesAndNewlines)
        if filledFields(description:description!) {
            let authorized:Bool = checkCalendarAuthorizationStatus()
            if authorized {
                addToCalendar()
            }
            addTask(description:description!)
            performSegue(withIdentifier: "unwindToTaskList", sender: self)
        }
        
    }
    
    func checkCalendarAuthorizationStatus() -> Bool{
        let status = EKEventStore.authorizationStatus(for: .event)
        if status == .authorized {
            return true
        }else{
            return false
        }
    }
    
    func addToCalendar(){
        let calendarIdentifier = UserDefaults.standard.string(forKey: "Binder")
        let calendar = eventStore.calendar(withIdentifier: calendarIdentifier!)
        if(calendar != nil) {
            //let startDate = Date()
//            let endDate = pickerDeadlineDate.date
//            let endTime = pickerDeadlineTime.date
            let endDate = deadlineDateTextField.text!
            let dateFormatter = DateFormatter()
            //dateFormatter.dateFormat = "mm/dd/yyyy"
            dateFormatter.dateStyle = .long
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            let date = dateFormatter.date(from: endDate)!
            //let startDate = endDate
            let c = Calendar.current
            //var components = c.dateComponents([.month, .day, .year], from: endDate)
            //components = c.dateComponents([.hour, .minute, .second], from: endTime)
            //let finalEndDate = c.date(from:components)
            let event = EKEvent(eventStore: eventStore)
            event.calendar = calendar
            event.title = taskDescriptionTextInput.text
            event.startDate = date
            //event.startDate = finalEndDate
            //event.endDate = finalEndDate
            event.endDate = date
            do {
                try eventStore.save(event, span: EKSpan.thisEvent)
                
//                    let alert = UIAlertController(title: "Event Saved", message: "Event was successfully saved", preferredStyle: .alert)
//                    let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//                    alert.addAction(OKAction)
//
//                    self.present(alert, animated: true, completion: nil)
            } catch _ {
//                    let alert = UIAlertController(title: "Event Save Error", message: "Event could not be saved", preferredStyle: .alert)
//                    let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//                    alert.addAction(OKAction)
//
//                    self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func addTask(description:String){
        //DataStore.shared.loadTasks()
        let index:Int = DataStore.shared.countTasks()
        let currentUserID = DataStore.shared.getIndexOfUserLoggedIn()
//        let task:Tasks = Tasks(taskID: index, taskDescription: description, taskDeadlineDate: deadlineDateTextField.text!, taskDeadlineTime: deadlineTimeTextField.text!, taskReminderDate: reminderDateTextField.text!, taskReminderTime: reminderTimeTextField.text!, personID: currentUserID, taskStartDate: String(describing: Date()))
        let task:Tasks = Tasks(taskID: index, taskDescription: description, taskDeadlineDate: deadlineDateTextField.text!, taskReminderDate: reminderDateTextField.text!, personID: currentUserID, taskStartDate: String(describing: Date()))
        DataStore.shared.addTask(task: task)
    }
    
    func filledFields(description:String) -> Bool{
        var filled: Bool = true
        if taskDescriptionTextInput.text == "" || deadlineDateTextField.text == "" || deadlineTimeTextField.text == "" || reminderDateTextField.text == "" || reminderTimeTextField.text == ""{
            errorLabel.text = "Please enter all fields"
            filled = false
        }
        return filled
    }
    
    @IBAction func clearButtonOnePressed(_ sender: Any) {
        deadlineDateTextField.text = ""
    }
    
    @IBAction func clearButtonTwoPressed(_ sender: Any) {
        deadlineTimeTextField.text = ""
    }
    
    @IBAction func clearButtonThreePressed(_ sender: Any) {
        reminderDateTextField.text = ""
    }
    
    @IBAction func clearButtonFourPressed(_ sender: Any) {
        reminderTimeTextField.text = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
