//
//  Assignments.swift
//  Binder
//
//  Created by Brandon Kerbow on 3/25/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import Foundation

class Assignments {
    fileprivate var _pk:Int = 0
    fileprivate var _assignmentID:Int = 0 //serial for a given
    //courseID and personID
    fileprivate var _assignmentTitle:String = ""
    fileprivate var _courseID:Int = 0
    fileprivate var _percentOfGrade:Int = 0
    fileprivate var _assignmentGrade:Int = 0
    fileprivate var _personID:Int = 0
    fileprivate var _assignmentDeadlineDate:String = ""
    fileprivate var _assignmentDeadlineTime:String = ""
    fileprivate var _assignmentReminderDate:String = ""
    fileprivate var _assignmentReminderTime:String = ""
    
    var pk:Int {
        get { return _pk }
        set (newValue) { _pk = newValue }
    }
    
    var assignmentID:Int {
        get { return _assignmentID }
        set (newValue) { _assignmentID = newValue }
    }
    var assignmentTitle:String {
        get { return _assignmentTitle }
        set(newVal) { _assignmentTitle = newVal }
    }
    var courseID:Int {
        get { return _courseID }
        set(newVal) { _courseID = newVal }
    }
    var percentOfGrade:Int {
        get { return _percentOfGrade }
        set(newVal) { _percentOfGrade = newVal }
    }
    var assignmentGrade:Int {
        get { return _assignmentGrade }
        set(newVal) { _assignmentGrade = newVal }
    }
    var personID:Int {
        get { return _personID }
        set(newVal) { _personID = newVal }
    }
    var assignmentDeadlineDate:String {
        get { return _assignmentDeadlineDate }
        set(newVal) { _assignmentDeadlineDate = newVal }
    }
    
    var assignmentDeadlineTime:String {
        get { return _assignmentDeadlineTime }
        set(newVal) { _assignmentDeadlineTime = newVal }
    }
    var assignmentReminderDate:String {
        get { return _assignmentReminderDate }
        set(newVal) { _assignmentReminderDate = newVal }
    }
    
    var assignmentReminderTime:String {
        get { return _assignmentReminderTime }
        set(newVal) { _assignmentReminderTime = newVal }
    }
    
  
    init(pk:Int, assignmentID:Int, assignmentTitle:String, courseID:Int, percentOfGrade:Int, assignmentGrade:Int, personID:Int, assignmentDeadlineDate:String, assignmentDeadlineTime:String, assignmentReminderDate:String, assignmentReminderTime: String ) {
        self._pk = pk
        self._assignmentID = assignmentID
        self._assignmentTitle = assignmentTitle
        self._courseID = courseID
        self._percentOfGrade = percentOfGrade
        self._assignmentGrade = assignmentGrade
        self._personID = personID
        self._assignmentDeadlineDate = assignmentDeadlineDate
        self._assignmentDeadlineTime = assignmentDeadlineTime
        self._assignmentReminderDate = assignmentReminderDate
        self._assignmentReminderTime = assignmentReminderTime
        
    }
    
    
    
}
