//
//  AddCourseViewController.swift
//  Binder
//
//  Created by Christina Depena on 3/31/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import UIKit

class AddCourseViewController: UIViewController, UITextFieldDelegate {
    // Connect the UI elements
    @IBOutlet weak var courseNameField: UITextField!
    @IBOutlet weak var courseAbbrField: UITextField!
    
    @IBOutlet weak var courseNameLabel: UILabel!
    @IBOutlet weak var courseAbbrLabel: UILabel!
    
    
    
    @IBOutlet weak var saveCourseButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set text field delegates in preparation for keyboard dismissal
        self.courseNameField.delegate = self
        self.courseAbbrField.delegate = self
        
        
       checkBackgroundColorAndFontSize()

        
        // Do any additional setup after loading the view.
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
       checkBackgroundColorAndFontSize()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Hide the keyboard when user presses return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return(true)
    }
    
    // Hide the keyboard when user touches outside keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func saveCourseBtn(_ sender: Any) {
       
        // Guard for empty fields and trigger an alert controller if fields are empty
        if((courseNameField.text == "") || (courseAbbrField.text == "")) {
            let alert = UIAlertController(title: "Error",
                                          message: "You must enter all course details",
                                          preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK",
                                         style: .default) { (action: UIAlertAction!) -> Void in
            }
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        } else {
        
            // Check to see if the course exists in course database yet
            //PersistenceService.shared.fetchCourses()
            
            //DataStore.shared.loadCourses()
         
            let courseCount = DataStore.shared.countOfCourses()
     
            //if there are already courses.... then check conditions before adding a course
            if courseCount > 0 {
               
                for i in 0...courseCount{
                    let course = DataStore.shared.getCourse(index: i)
                    guard(course.courseName != courseNameField.text && course.courseAbbreviation != courseAbbrField.text) else {
                        return
                    }
                    // Add the new course if it passes the guard
                    let currentCourseCount = courseCount + 1
                    let courseToSave: Courses = Courses(courseName: courseNameField.text!, courseAbbreviation: courseAbbrField.text!, courseID: currentCourseCount - 1) // -1 because all of our firebase indices start at 0, so let's just be consistent
                    DataStore.shared.addCourse(course: courseToSave)
                    
                    
                
                    
                    // Update the PeopleInCourse database
                    // Retrieve current user's username and ID
                    

                    
                    let currentUserID =  (DataStore.shared.getPerson(index: DataStore.shared.getIndexOfUserLoggedIn())).personID
                    //DataStore.shared.loadPeopleInCourses()
                    let peopleInCoursesCount = DataStore.shared.countOfPeopleInCourses()
                    print("people in courses count1:")
                    print(peopleInCoursesCount)
                    
                    let peopleInCoursesObjectToAdd: PeopleInCourses = PeopleInCourses(courseID: currentCourseCount - 1, personID: currentUserID, pk: peopleInCoursesCount) // -1 because all of our firebase indices start at 0, so let's just be consistent
                    DataStore.shared.addPeopleInCourse(peopleInCourse: peopleInCoursesObjectToAdd)
                    return
                    
                    
                }
            } else {
           
                //when no courses exist yet then go ahead and add the coruse, no need to check the guard because no other courses exist
                let currentCourseCount = courseCount + 1
                let courseToSave: Courses = Courses(courseName: courseNameField.text!, courseAbbreviation: courseAbbrField.text!, courseID: currentCourseCount - 1)
                DataStore.shared.addCourse(course: courseToSave)
                
                
                
                
                // Update the PeopleInCourse database
                // Retrieve current user's username and ID
                
                
                
                let currentUserID =  (DataStore.shared.getPerson(index: DataStore.shared.getIndexOfUserLoggedIn())).personID
                //DataStore.shared.loadPeopleInCourses()
                let peopleInCoursesCount = DataStore.shared.countOfPeopleInCourses()
                print("people in courses count:2")
                print(peopleInCoursesCount)
                
                let peopleInCoursesObjectToAdd: PeopleInCourses = PeopleInCourses(courseID: currentCourseCount - 1, personID: currentUserID, pk: peopleInCoursesCount)
                DataStore.shared.addPeopleInCourse(peopleInCourse: peopleInCoursesObjectToAdd)
                return
                
            }
            
            
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    func checkBackgroundColorAndFontSize() {
        
        //setting the background color and font sizes of this
        //VC based on user default settings
        //see the SettingsViewController and also Config
        //classes for more info
        
        
        if DataStore.shared.getPerson(index: DataStore.shared.getIndexOfUserLoggedIn()).backgroundColor == "blue" {
            self.view.backgroundColor = UIColor.cyan
        } else {
            self.view.backgroundColor = UIColor.white
        }
        
        //set font sizes
        if DataStore.shared.getPerson(index: DataStore.shared.getIndexOfUserLoggedIn()).fontSize == "small" {
            
            saveCourseButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
       
            
            courseAbbrLabel.font = UIFont.systemFont(ofSize: 15.0)
            courseNameLabel.font = UIFont.systemFont(ofSize: 15.0)
            
            courseNameField.font = UIFont.systemFont(ofSize: 15.0)
            courseAbbrField.font = UIFont.systemFont(ofSize: 15.0)
            
            
            
        } else {
            saveCourseButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
         
            
            courseAbbrLabel.font = UIFont.systemFont(ofSize: 20.0)
            courseNameLabel.font = UIFont.systemFont(ofSize: 20.0)
            
            courseNameField.font = UIFont.systemFont(ofSize: 20.0)
            courseAbbrField.font = UIFont.systemFont(ofSize: 20.0)
            
        }
        
        
    }
    

}
 

