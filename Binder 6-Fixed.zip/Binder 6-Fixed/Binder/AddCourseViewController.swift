//
//  AddCourseViewController.swift
//  Binder
//
//  Created by Christina Depena on 3/31/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import UIKit

class AddCourseViewController: UIViewController, UITextFieldDelegate {
    // Connect the UI elements
    @IBOutlet weak var courseNameField: UITextField!
    @IBOutlet weak var courseAbbrField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set text field delegates in preparation for keyboard dismissal
        self.courseNameField.delegate = self
        self.courseAbbrField.delegate = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Hide the keyboard when user presses return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return(true)
    }
    
    // Hide the keyboard when user touches outside keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func saveCourseBtn(_ sender: Any) {
        // Guard for empty fields and trigger an alert controller if fields are empty
        if((courseNameField.text == "") || (courseAbbrField.text == "")) {
            let alert = UIAlertController(title: "Error",
                                          message: "You must enter all course details",
                                          preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK",
                                         style: .default) { (action: UIAlertAction!) -> Void in
            }
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        } else {
        
        // Check to see if the course exists in course database yet
        PersistenceService.shared.fetchCourses()
        let courseCount = PersistenceService.shared.countCourses()
        for i in 0...courseCount{
            let course = PersistenceService.shared.getCourse(index: i)
            guard(course.courseName != courseNameField.text && course.courseAbbreviation != courseAbbrField.text) else {
                return
            }
            // Add the new course if it passes the guard
            let currentCourseCount = courseCount + 1
            PersistenceService.shared.saveCourses(courseAbbreviation: courseAbbrField.text!, courseID: currentCourseCount, courseName: courseNameField.text!)
            
            // Update the PeopleInCourse database
            // Retrieve current user's username and ID
            let currentUser = Config.getUsernameOfUserLoggedIn()
            let currentUserID = Config.determineTheIndexOfUser(currentUser)
            let peopleInCoursesCount = PersistenceService.shared.countPeopleInCourses()
            PersistenceService.shared.savePeopleInCourses(courseID: currentCourseCount, personID: currentUserID, pk: peopleInCoursesCount + 1)
            return
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
