//
//  Config.swift
//  Binder
//
//  Created by Brandon Kerbow on 3/25/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//



//This class is our app's user defaults

import Foundation

class Config: NSObject {
    // Define keys for the values to store
    //these are given values when a user logs in
    //see the loginViewController for when calls to this class happen
    
    fileprivate static var keyForUsernameOfUserLoggedIn: String? = nil
    fileprivate static var keyForLoggedInUsersBackgroundColor: String? = nil
    fileprivate static var keyForLoggedInUsersFontSize: String? = nil
    
    //this is called when the user logs in so that the app knows which user is logged in and
    //that users settings can be called from the configuration class
    class func specifyUsername(_ username:String) {
        
        keyForUsernameOfUserLoggedIn = username
        setUsernameOfUserLoggedIn(username)
        let theIndexOfTheUser = determineTheIndexOfUser(username)
        
        keyForLoggedInUsersBackgroundColor = String(PersistenceService.shared.getPeople(index:theIndexOfTheUser).personID)  + "background"
        
        keyForLoggedInUsersFontSize = String(PersistenceService.shared.getPeople(index:theIndexOfTheUser).personID) + "fontSize"
        
        //when a user logs in, get their background and text value
        
    }
    
    //to determine the user logged in, look through the core data until you see the person with the name
    //which was passed in from the login screen
    class func determineTheIndexOfUser(_ userNameOfPersonLoggedIn:String) -> Int {
        
        for i in 0...PersistenceService.shared.countPeople() - 1 {
            
            if  (keyForUsernameOfUserLoggedIn == PersistenceService.shared.getPeople(index: i).username) {
                return i
            }
        }
        return 0
    }
    
    //anywhere in the app should be able to set the font size or color or name of the user logged in
    class func setUserBackgroundColor(_ color:String) {
        UserDefaults.standard.set(color, forKey: keyForLoggedInUsersBackgroundColor!)
        UserDefaults.standard.synchronize()
    }
    class func setUserFontSize(_ fontSize:String) {
        UserDefaults.standard.set(fontSize, forKey: keyForLoggedInUsersFontSize!)
        UserDefaults.standard.synchronize()
    }
    
    class func setUsernameOfUserLoggedIn(_ username:String) {
        UserDefaults.standard.set(username, forKey: keyForUsernameOfUserLoggedIn!)
        UserDefaults.standard.synchronize()
    }
    
    //anywhere in the app should be able to get the font size or color or name of the user logged in
    class func getUserBackgroundColor() -> String {
        
        if UserDefaults.standard.string(forKey: keyForLoggedInUsersBackgroundColor!) != nil {
            
            return UserDefaults.standard.string(forKey: keyForLoggedInUsersBackgroundColor!)!
        } else {
            Config.setUserBackgroundColor("blue")
            return UserDefaults.standard.string(forKey: keyForLoggedInUsersBackgroundColor!)!
        }
        
    }
    
    class func getUserFontSize() -> String {
        
        if UserDefaults.standard.string(forKey: keyForLoggedInUsersFontSize!) != nil {
            
            return UserDefaults.standard.string(forKey: keyForLoggedInUsersFontSize!)!
        } else {
            Config.setUserFontSize("small")
            return UserDefaults.standard.string(forKey: keyForLoggedInUsersFontSize!)!
        }
        
    }
    
    class func getUsernameOfUserLoggedIn() -> String {
        return UserDefaults.standard.string(forKey: keyForUsernameOfUserLoggedIn!)!
    }
    
}
