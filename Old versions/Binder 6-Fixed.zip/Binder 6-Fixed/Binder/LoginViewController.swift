//
//  LoginViewController.swift
//  Binder
//
//  Created by Isaac on 3/26/18.
//  Copyright © 2018 The University of Texas at Austin. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        PersistenceService.shared.fetchPeople()
        errorLabel.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButton(_ sender: Any) {
        if fieldsFilled() {
            if credentialsCorrect() {
                performSegue(withIdentifier: "tabBarControllerSegue", sender: nil)
                //this sets the name of the user in the user defaults (user defaults is wrapped in the config class)
                Config.specifyUsername(usernameTextField.text!)
            }
        }
    }
    
    func credentialsCorrect() -> Bool {
        let givenUsername = usernameTextField.text
        let givenPassword = passwordTextField.text
        let count = PersistenceService.shared.countPeople()
        for i in 0...count{
            let person = PersistenceService.shared.getPeople(index: i)
            if person.username == givenUsername {
                if person.password == givenPassword {
                    return true
                }
            }

        }
        errorLabel.text = "Username or Password is incorrect"
        return false
    }
    
    func fieldsFilled() -> Bool{
        if usernameTextField.text == "" || passwordTextField.text == "" {
            errorLabel.text = "Enter both username and password"
            return false
        }else {
            return true
        }
    }

    @IBAction func unwindToLogIn(segue: UIStoryboardSegue){}
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    //override func prepare(for segue: UIStoryboardSegue, sender: Any?) {}
    

}
